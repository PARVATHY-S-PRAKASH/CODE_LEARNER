package com.example.cap;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class LanguageChoose extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_choose);

        ImageView img = findViewById(R.id.promax);
        Glide.with(getApplicationContext()).load(R.drawable.nec_final).into(img);
    }
}