package com.example.cap;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.github.barteksc.pdfviewer.PDFView;
import com.google.android.material.navigation.NavigationView;

public class Examples extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        switch (getIntent().getStringExtra("lang")){
            case "cpp":
                setContentView(R.layout.activity_examples_cpp);
                setPDF("cpp_overview");
                drawerCPP();
                break;
            case "py":
                setContentView(R.layout.activity_examples_py);
                setPDF("py_overview");
                drawerPy();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + getIntent().getStringExtra("lang"));
        }
    }

    public void drawerCPP(){
        DrawerLayout drawerLayout;
        NavigationView navigationView;
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.drawer_syntax:
                        setPDF("cpp_syntax");
                        break;
                    case R.id.drawer_storageclass:
                        setPDF("cpp_storageclasses");
                        break;
                    case R.id.drawer_operators:
                        setPDF("cpp_operators");
                        break;
                    case R.id.drawer_modifiertypes:
                        setPDF("cpp_modifiertypes");
                        break;
                    case R.id.drawer_constandlit:
                        setPDF("cpp_constandlit");
                        break;
                    case R.id.drawer_varscope:
                        setPDF("cpp_variablescope");
                        break;
                    case R.id.drawer_variables:
                        setPDF("cpp_variabletypes");
                        break;
                    case R.id.drawer_datatypes:
                        setPDF("cpp_datatypes");
                        break;
                    case R.id.drawer_comment:
                        setPDF("cpp_comment");
                        break;
                    case R.id.drawer_overview:
                        setPDF("cpp_overview");
                        break;
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
        findViewById(R.id.ham).setOnClickListener(view -> drawerLayout.openDrawer(GravityCompat.START));

    }

    public void drawerPy(){
        DrawerLayout drawerLayout;
        NavigationView navigationView;
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.drawer_syntax:
                        setPDF("py_syntax");
                        break;
                    case R.id.drawer_loops:
                        setPDF("py_loops");
                        break;
                    case R.id.drawer_lists:
                        setPDF("py_lists");
                        break;
                    case R.id.drawer_strings:
                        setPDF("py_strings");
                        break;
                    case R.id.drawer_numbers:
                        setPDF("py_numbers");
                        break;
                    case R.id.drawer_decisionmaking:
                        setPDF("py_decisionmaking");
                        break;
                    case R.id.drawer_variables:
                        setPDF("py_variables");
                        break;
                    case R.id.drawer_excepthandling:
                        setPDF("py_exceptionhandling");
                        break;
                    case R.id.drawer_operators:
                        setPDF("py_operators");
                        break;
                    case R.id.drawer_overview:
                        setPDF("py_overview");
                        break;
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
        findViewById(R.id.ham).setOnClickListener(view -> drawerLayout.openDrawer(GravityCompat.START));
    }

    public void setPDF(String name){
        PDFView pdfView = findViewById(R.id.pdfView);
        pdfView.fromAsset(name+".pdf")
                .pages(0, 2, 1, 3, 3, 3) // all pages are displayed by default
                .enableSwipe(true) // allows to block changing pages using swipe
                .swipeHorizontal(false)
                .enableDoubletap(true)
                .defaultPage(0)
                .enableAnnotationRendering(false) // render annotations (such as comments, colors or forms)
                .password(null)
                .scrollHandle(null)
                .enableAntialiasing(true) // improve rendering a little bit on low-res screens
                // spacing between pages in dp. To define spacing color, set view background
                .spacing(0)
                .autoSpacing(false) // add dynamic spacing to fit each page on its own on the screen
                .pageSnap(false) // snap pages to screen boundaries
                .pageFling(false) // make a fling change only a single page like ViewPager
                .nightMode(false) // toggle night mode
                .load();
    }
}