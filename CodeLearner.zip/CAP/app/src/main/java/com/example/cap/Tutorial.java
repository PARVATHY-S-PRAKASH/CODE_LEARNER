package com.example.cap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class Tutorial extends AppCompatActivity {

    String lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String lng = getIntent().getStringExtra("lng");
        switch (lng){
            case "java":
                setContentView(R.layout.activity_tutorialjava);
                findViewById(R.id.websitecard).setOnClickListener(view -> {
                    Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    httpintent.setData(Uri.parse("https://www.java.com/en/"));
                    startActivity(httpintent);
                });
                lang = "1";
                break;
            case "python":
                setContentView(R.layout.activity_tutorialpython);
                findViewById(R.id.excard).setOnClickListener(view -> startActivity(new Intent(getApplicationContext(),Examples.class).putExtra("lang","py")));
                findViewById(R.id.websitecard).setOnClickListener(view -> {
                    Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    httpintent.setData(Uri.parse("https://www.python.org/"));
                    startActivity(httpintent);
                });
                lang = "2";
                break;
            case "kotlin":
                setContentView(R.layout.activity_tutorialkotlin);
                findViewById(R.id.websitecard).setOnClickListener(view -> {
                    Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    httpintent.setData(Uri.parse("https://kotlinlang.org/"));
                    startActivity(httpintent);
                });
                lang = "3";
                break;
            case "cpp":
                setContentView(R.layout.activity_tutorialcpp);
                findViewById(R.id.excard).setOnClickListener(view -> startActivity(new Intent(getApplicationContext(),Examples.class).putExtra("lang","cpp")));
                findViewById(R.id.websitecard).setOnClickListener(view -> {
                    Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    httpintent.setData(Uri.parse("https://cplusplus.com/doc/tutorial/"));
                    startActivity(httpintent);
                });
                lang = "4";
                break;
            case "php":
                setContentView(R.layout.activity_tutorialphp);
                findViewById(R.id.websitecard).setOnClickListener(view -> {
                    Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    httpintent.setData(Uri.parse("https://www.php.net/"));
                    startActivity(httpintent);
                });
                lang = "5";
                break;
            default:
                setContentView(R.layout.activity_tutorial);
                break;
        }
        findViewById(R.id.videocard).setOnClickListener(view ->  startActivity(new Intent(getApplicationContext(),TutorialList.class).putExtra("lng",lng)));
        findViewById(R.id.pdfcard).setOnClickListener(view -> startActivity(new Intent(getApplicationContext(),Compiler.class).putExtra("lang",lang)));
    }
}