package com.example.cap;

import android.content.Intent;
import android.net.Uri;
import android.view.ViewGroup;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

public  class TutorialListAdapter extends RecyclerView.Adapter<TutorialListAdapter.ViewHolder> {


    public List<CA> articles;
    public Context context;
//    Globalvar globalvar;

    public TutorialListAdapter(List<CA> articles, Context context) {
        this.articles = articles;
        this.context = context;
//        this.globalvar=globalvar;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_vlist, parent, false);
        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        CA item = articles.get(position);

        holder.head.setText(item.head);

        String url = item.imagelink;
        // Retrieves an image specified by the URL, displays it in the UI.
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        // Initialize a new ImageRequest
        ImageRequest imageRequest = new ImageRequest(
                url, // Image URL
                new Response.Listener<Bitmap>() { // Bitmap listener
                    @Override
                    public void onResponse(Bitmap response) {
                        holder.imageView.setImageBitmap(response);
                    }
                },
                0, // Image width
                0, // Image height
                ImageView.ScaleType.CENTER_CROP, // Image scale type
                Bitmap.Config.RGB_565, //Image decode configuration
                new Response.ErrorListener() { // Error listener
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Do something with error response
                        error.printStackTrace();
                    }
                }
        )  {
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("user","YOUR USERNAME");
                params.put("pass","YOUR PASSWORD");
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }

        };
        imageRequest.setShouldCache(false);
        // Add ImageRequest to the RequestQueue
        requestQueue.add(imageRequest);

        holder.cardView.setOnClickListener(view -> {
            Intent httpintent=new Intent(Intent.ACTION_VIEW).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            httpintent.setData(Uri.parse("https://www.youtube.com/watch?v="+item.getRedirectlink()));
            context.startActivity(httpintent);
        });
    }

    @Override
    public int getItemCount() {
        return articles.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView head;
        ImageView imageView;
        CardView cardView;
        public ViewHolder(View itemView) {
            super(itemView);
            head=itemView.findViewById(R.id.vtitle);
            imageView=itemView.findViewById(R.id.image);
            cardView=itemView.findViewById(R.id.newcard);
        }

    }


    public static class CA{
        String head,description,redirectlink,imagelink;

        public String getHead() {
            return head;
        }

        public String getDescription() {
            return description;
        }

        public String getRedirectlink() {
            return redirectlink;
        }

        public String getImagelink() {
            return imagelink;
        }

        public CA(String head, String description, String redirectlink, String imagelink) {
            this.head = head;
            this.description = description;
            this.redirectlink = redirectlink;
            this.imagelink = imagelink;
        }
    }
}

