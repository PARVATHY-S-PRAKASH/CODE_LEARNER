package com.example.cap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class Home extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_choose);

        findViewById(R.id.compile).setOnClickListener(view -> nextactivity("python"));
        findViewById(R.id.compile2).setOnClickListener(view -> nextactivity("java"));
        findViewById(R.id.compile3).setOnClickListener(view -> nextactivity("kotlin"));
        findViewById(R.id.compile4).setOnClickListener(view -> nextactivity("php"));
        findViewById(R.id.compile5).setOnClickListener(view -> nextactivity("cpp"));

        ImageView img = findViewById(R.id.promax);
        Glide.with(getApplicationContext()).load(R.drawable.nec_final).into(img);
    }
    public void nextactivity(String string){
        startActivity(new Intent(getApplicationContext(),Tutorial.class).putExtra("lng",string));
    }
}