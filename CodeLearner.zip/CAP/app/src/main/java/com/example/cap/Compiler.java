package com.example.cap;

import static com.android.volley.VolleyLog.TAG;
import static com.android.volley.VolleyLog.v;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationHolder;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.basgeekball.awesomevalidation.utility.custom.CustomErrorReset;
import com.basgeekball.awesomevalidation.utility.custom.CustomValidation;
import com.basgeekball.awesomevalidation.utility.custom.CustomValidationCallback;
import com.google.android.material.button.MaterialButton;

import org.json.JSONException;
import org.json.JSONObject;

public class Compiler extends AppCompatActivity {

    MaterialButton submitscript;
    Spinner languageSpinner;
    EditText scriptarea;
    EditTextPro outputarea;
    AwesomeValidation awesomeValidation;
    String lang;

    String[] languages = { "< Please select one >", "Java", "Python", "Kotlin" , "CPP", "PHP"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compiler);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        submitscript = findViewById(R.id.submitscript);
        scriptarea = findViewById(R.id.scriptarea);
        languageSpinner = findViewById(R.id.languageSpinner);
        outputarea = findViewById(R.id.outputarea);
        outputarea.setKeyListener(null);


        awesomeValid();
        languageSpinner();

        findViewById(R.id.clearscript).setOnClickListener(view -> {
            scriptarea.setText("");
            outputarea.setText("");
        });

        submitscript.setOnClickListener(view -> {
            if (awesomeValidation.validate()) {
                execAPI();
                }
            }
        );

        submitscript.setOnLongClickListener(view -> {
            startActivity(new Intent(getApplicationContext(),Home.class));
            return true;
        });

    }

    public void execAPI() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Compiling");
        progressDialog.show();
        JSONObject jsonBodyObj = new JSONObject();
        try {
            jsonBodyObj.put("clientId", getResources().getString(R.string.clientId));
            jsonBodyObj.put("clientSecret", getResources().getString(R.string.clientSecret));
            jsonBodyObj.put("script", scriptarea.getText().toString() );
            jsonBodyObj.put("language", lang);
            jsonBodyObj.put("versionIndex", "0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "execAPI: "+ jsonBodyObj);
        final JsonParserVolley jsonParserVolley = new JsonParserVolley(this);

        jsonParserVolley.params(getResources().getString(R.string.execUrl), jsonBodyObj);
        jsonParserVolley.executeRequest(Request.Method.POST, new JsonParserVolley.VolleyCallback() {

                    @Override
                    public void getResponse(String response) {
                        Log.d("TAG", response);
                        JSONObject jsonObject = null;
                        try {
                            jsonObject = new JSONObject(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            assert jsonObject != null;
                            if (jsonObject.getString("statusCode").equals("200")) {
                                try {
                                    progressDialog.cancel();
                                    outputarea.setText(jsonObject.getString("output"));
                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();

                                    e.printStackTrace();
                                }
                            } else {
                                progressDialog.cancel();
                                outputarea.setText(jsonObject.getString("output"));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
    }

    public void awesomeValid(){

        awesomeValidation.addValidation(this, R.id.scriptarea, RegexTemplate.NOT_EMPTY, R.string.invalid_script);
        awesomeValidation.addValidation(this, R.id.languageSpinner, new CustomValidation() {
            @Override
            public boolean compare(ValidationHolder validationHolder) {
                return !((Spinner) validationHolder.getView()).getSelectedItem().toString().equals("< Please select one >");
            }
        }, new CustomValidationCallback() {
            @Override
            public void execute(ValidationHolder validationHolder) {
                TextView textViewError = (TextView) ((Spinner) validationHolder.getView()).getSelectedView();
                textViewError.setError(validationHolder.getErrMsg());
                textViewError.setTextColor(Color.RED);
            }
        }, new CustomErrorReset() {
            @Override
            public void reset(ValidationHolder validationHolder) {
                TextView textViewError = (TextView) ((Spinner) validationHolder.getView()).getSelectedView();
                textViewError.setError(null);
                textViewError.setTextColor(Color.BLACK);
            }
        }, R.string.invalid_language);



    }

    public void languageSpinner(){

        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 1:
                        lang = "java";
                        break;
                    case 2:
                        lang = "python3";
                        break;
                    case 3:
                        lang = "kotlin";
                        break;
                    case 4:
                        lang = "cpp";
                        break;
                    case 5:
                        lang = "php";
                        break;
                    default:
                        lang = "";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter omDuraAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, languages);
        omDuraAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(omDuraAdapter);

        if (getIntent().getStringExtra("lang")!=null){
            languageSpinner.setSelection(Integer.parseInt(getIntent().getStringExtra("lang")));
        }

    }

}