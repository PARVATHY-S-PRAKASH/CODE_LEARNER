package com.example.cap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.Resources;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class TutorialList extends AppCompatActivity {
    public RecyclerView prorecyclerView;
    JSONObject jsonObject;
    InputStream is;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial_list);

        prorecyclerView = findViewById(R.id.recycler_view);

        LinearLayoutManager verticallayout  = new LinearLayoutManager(
                getApplicationContext(),
                LinearLayoutManager.VERTICAL,
                false);
        prorecyclerView.setLayoutManager(verticallayout);

        List<TutorialListAdapter.CA> prolistItems = new ArrayList<>();

        String lng = getIntent().getStringExtra("lng");

        switch (lng){
            case "java":
                is = getResources().openRawResource(R.raw.pjava);
                break;
            case "python":
                is = getResources().openRawResource(R.raw.ppython);
                break;
            case "kotlin":
                is = getResources().openRawResource(R.raw.pkotlin);
                break;
            case "cpp":
                is = getResources().openRawResource(R.raw.pcpp);
                break;
            case "php":
                is = getResources().openRawResource(R.raw.pphp);
                break;
            default:
                break;
        }




        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String jsonString = writer.toString();

        try {
            jsonObject=new JSONObject(jsonString);

            JSONArray jsonArray = jsonObject.getJSONArray("items");
            {
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject o = jsonArray.getJSONObject(i);

                    JSONObject snippet=o.getJSONObject("snippet");
                    JSONObject resourceId=snippet.getJSONObject("resourceId");

                    JSONObject thumbnails=snippet.getJSONObject("thumbnails");
                    JSONObject defaults=thumbnails.getJSONObject("default");


                    TutorialListAdapter.CA item = new TutorialListAdapter.CA(
                            snippet.getString("title"),
                            snippet.getString("description"),
                            resourceId.getString("videoId"),
                            defaults.getString("url")
                    );
                    prolistItems.add(item);
                }

                RecyclerView.Adapter  proadp = new TutorialListAdapter(prolistItems, getApplicationContext());
                prorecyclerView.setAdapter(proadp);
        }
    } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}