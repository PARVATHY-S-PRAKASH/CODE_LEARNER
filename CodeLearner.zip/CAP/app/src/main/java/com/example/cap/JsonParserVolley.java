package com.example.cap;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class JsonParserVolley {

    final String contentType = "application/json; charset=utf-8";
    String JsonURL = "Your URL";
    Context context;
    RequestQueue requestQueue;
    String jsonresponse,requestBody;


    private Map<String, String> header;

    public JsonParserVolley(Context context) {
        this.context = context;
        requestQueue = Volley.newRequestQueue(context);
        header = new HashMap<>();

    }

    public void addHeader(String key, String value) {
        header.put(key, value);
    }
    public void params(String url, JSONObject jsonBodyObj)
    {
        JsonURL = url;
        requestBody = jsonBodyObj.toString();

    }

    public void executeRequest(int method, final VolleyCallback callback) {

        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(method,
                    JsonURL, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(final JSONObject response) {
                    jsonresponse = response.toString();
//                    Log.e("RES", " res::" + jsonresponse);
                    callback.getResponse(jsonresponse);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.e("Error:",error.getMessage());
//                    Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Text", "application/json");
                    headers.put("User-Agent", "Mozilla/5.0");

                    return headers;
                }

                @Override
                public byte[] getBody() {
                    try {
                        return requestBody == null ? null : requestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s",
                                requestBody, "utf-8");
                        return null;
                    }
                }
            };
            requestQueue.add(jsonObjectRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface VolleyCallback
    {
        public void getResponse(String response);
    }
}
