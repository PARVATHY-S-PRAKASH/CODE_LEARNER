package com.example.cap;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;

public class EditTextPro extends androidx.appcompat.widget.AppCompatEditText {

    private Rect rect;
    private Paint paint;

    public EditTextPro(Context context) {
        super(context);
        init();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int baseline = getBaseline();
        for (int i = 0; i < getLineCount(); i++) {
            if(i+1<10){
                canvas.drawText("  " + (i+1), rect.left, baseline, paint);
            }
            else {
                canvas.drawText(" " + (i+1), rect.left, baseline, paint);
            }
            baseline += getLineHeight();
        }
        super.onDraw(canvas);
    }

    public EditTextPro(Context context, AttributeSet attrs) {
        super(context,attrs);
        init();
    }

    private void init(){

        rect = new Rect();
        paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.GRAY);
        paint.setTextSize(30);
    }
}
